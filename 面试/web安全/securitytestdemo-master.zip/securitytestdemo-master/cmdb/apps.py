from django.apps import AppConfig


class CmdbConfig(AppConfig):
    name = 'cmdb'
